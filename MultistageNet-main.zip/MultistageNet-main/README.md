# Multistage Net

## Get Started
1. Install Python 3.7, Pytorch 1.9.0
2. Train the model. We provide experiment scripts under the foler scripts. 

```bash
bash ./scripts/run_seqlen_12.sh
bash ./scripts/run_seqlen_24.sh
bash ./scripts/run_seqlen_48.sh
```